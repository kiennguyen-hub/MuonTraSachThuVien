using System.Data.Common;
using BTL_SRS.Data;
using BTL_SRS.Middleware;
using BTL_SRS.Models;
using BTL_SRS.Services;
using Microsoft.AspNetCore.Hosting.StaticWebAssets;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();
builder.Services.AddRazorPages();
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

builder.Services.AddIdentity<User, IdentityRole<int>>(options =>
{
    // Mat khau mau cua bai tap la 123456, nen cau hinh Identity de chap nhan.
    options.Password.RequiredLength = 6;
    options.Password.RequireDigit = false;
    options.Password.RequireLowercase = false;
    options.Password.RequireUppercase = false;
    options.Password.RequireNonAlphanumeric = false;
    options.User.RequireUniqueEmail = true;
    options.SignIn.RequireConfirmedAccount = false;
})
.AddEntityFrameworkStores<AppDbContext>()
.AddDefaultTokenProviders();

builder.Services.ConfigureApplicationCookie(options =>
{
    options.Cookie.Name = "BTL_SRS.Auth";
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
    options.Cookie.SameSite = SameSiteMode.Lax;
    options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
    options.LoginPath = "/Account/Login";
    options.AccessDeniedPath = "/Account/AccessDenied";
    options.ExpireTimeSpan = TimeSpan.FromMinutes(
        builder.Configuration.GetValue<int?>("Identity:ExpireMinutes") ?? 30);
    options.SlidingExpiration = true;
});

builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("ManageBooks", policy =>
        policy.RequireRole(AppRoles.Admin, AppRoles.Librarian));
    options.AddPolicy("AdminOnly", policy =>
        policy.RequireRole(AppRoles.Admin));
});

builder.Services.AddDistributedMemoryCache();
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(
        builder.Configuration.GetValue<int?>("Session:IdleTimeoutMinutes") ?? 20);
    options.Cookie.Name = "BTL_SRS.Session";
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
    options.Cookie.SameSite = SameSiteMode.Lax;
    options.Cookie.SecurePolicy = CookieSecurePolicy.SameAsRequest;
});

builder.Services.AddHttpContextAccessor();
builder.Services.AddDataProtection();
builder.Services.AddScoped<VisitorStateService>();
builder.Services.AddScoped<SessionStateService>();

var app = builder.Build();

// Khi chay truc tiep tu thu muc build (khong qua dotnet run/Visual Studio),
// static web assets khong duoc bat nen file .js/.css co the tra ve rong.
var runtimeManifest = Path.Combine(AppContext.BaseDirectory, "BTL_SRS.staticwebassets.runtime.json");
if (!app.Environment.IsDevelopment() && File.Exists(runtimeManifest))
{
    StaticWebAssetsLoader.UseStaticWebAssets(app.Environment, app.Configuration);
}

// Tu dong migrate + seed du lieu mau. LocalDB co the can vai giay de san sang
// sau khi Visual Studio hoac mot tien trinh debug truoc do vua dung lai.
const int maxDatabaseAttempts = 5;
for (var attempt = 1; ; attempt++)
{
    try
    {
        using (var scope = app.Services.CreateScope())
        {
            var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
            var userManager = scope.ServiceProvider.GetRequiredService<UserManager<User>>();
            var roleManager = scope.ServiceProvider.GetRequiredService<RoleManager<IdentityRole<int>>>();
            await db.Database.MigrateAsync();
            await SeedData.InitAsync(db, userManager, roleManager);
        }

        break;
    }
    catch (DbException ex) when (attempt < maxDatabaseAttempts)
    {
        app.Logger.LogWarning(
            ex,
            "Khong ket noi duoc co so du lieu (lan {Attempt}/{MaxAttempts}). Thu lai sau 2 giay.",
            attempt,
            maxDatabaseAttempts);
        await Task.Delay(TimeSpan.FromSeconds(2));
    }
    catch (DbException ex)
    {
        app.Logger.LogError(
            ex,
            "Khong ket noi duoc co so du lieu sau {MaxAttempts} lan thu. Ung dung van chay de hien thi thong bao loi o trang dang nhap. Hay chay 'sqllocaldb start MSSQLLocalDB' roi khoi dong lai ung dung.",
            maxDatabaseAttempts);
        break;
    }
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseRouting();
app.UseSession();
app.UseAuthentication();
app.UseAuthorization();
app.UseMiddleware<VisitorTrackingMiddleware>();
app.MapStaticAssets();

// Razor Pages routing
app.MapRazorPages();

// API routes (Controllers)
app.MapControllerRoute(name: "default", pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
