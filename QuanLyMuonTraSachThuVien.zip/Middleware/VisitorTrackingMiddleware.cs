using BTL_SRS.Services;
using Microsoft.AspNetCore.Mvc.Controllers;

namespace BTL_SRS.Middleware;

public class VisitorTrackingMiddleware
{
    private readonly RequestDelegate _next;

    public VisitorTrackingMiddleware(RequestDelegate next)
    {
        _next = next;
    }

    public async Task InvokeAsync(HttpContext context, VisitorStateService visitorState, SessionStateService sessionState)
    {
        var function = GetFunction(context);
        if (function != null)
        {
            visitorState.Track(function);

            if (context.User.Identity?.IsAuthenticated == true)
                sessionState.Touch(function);
        }

        await _next(context);
    }

    private static string? GetFunction(HttpContext context)
    {
        var descriptor = context.GetEndpoint()?.Metadata.GetMetadata<ControllerActionDescriptor>();
        return descriptor == null ? null : $"{descriptor.ControllerName}/{descriptor.ActionName}";
    }
}
