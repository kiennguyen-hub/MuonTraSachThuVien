using System.ComponentModel.DataAnnotations;

namespace BTL_SRS.Models;

// Bang BorrowRecords (SRS 5.1, Table 12)
public enum BorrowStatus { Pending, Borrowed, Returned, Overdue }

public class BorrowRecord
{
    public int Id { get; set; }

    public int UserId { get; set; }
    public User? User { get; set; }          // nguoi muon

    public int BookId { get; set; }
    public Book? Book { get; set; }          // sach duoc muon

    [DataType(DataType.Date)]
    public DateTime BorrowDate { get; set; } = DateTime.Today;

    [DataType(DataType.Date)]
    public DateTime DueDate { get; set; } = DateTime.Today.AddDays(14);

    [DataType(DataType.Date)]
    public DateTime? ReturnDate { get; set; }

    public BorrowStatus Status { get; set; } = BorrowStatus.Pending;

    public int? ApprovedBy { get; set; }     // thu thu duyet
    public User? Approver { get; set; }
}
