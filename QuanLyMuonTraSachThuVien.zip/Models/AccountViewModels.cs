using System.ComponentModel.DataAnnotations;
using BTL_SRS.Services;

namespace BTL_SRS.Models;

public class LoginViewModel
{
    [Required(ErrorMessage = "Vui lòng nhập tên đăng nhập hoặc email.")]
    [Display(Name = "Tên đăng nhập hoặc email")]
    public string UserNameOrEmail { get; set; } = "";

    [Required(ErrorMessage = "Vui lòng nhập mật khẩu.")]
    [DataType(DataType.Password)]
    [Display(Name = "Mật khẩu")]
    public string Password { get; set; } = "";
}

public class ProfileViewModel
{
    public User User { get; set; } = null!;
    public IList<string> Roles { get; set; } = new List<string>();
    public SessionUserState? Session { get; set; }
    public VisitorState Visitor { get; set; } = new();
    public string AuthenticationType { get; set; } = "";
}
