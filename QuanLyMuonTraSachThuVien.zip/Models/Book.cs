using System.ComponentModel.DataAnnotations;

namespace BTL_SRS.Models;

// Bang Books (SRS 5.1, Table 11)
public class Book
{
    public int Id { get; set; }

    [Required, StringLength(200)]
    public string Title { get; set; } = "";

    public int CategoryId { get; set; }
    public Category? Category { get; set; }

    public int AuthorId { get; set; }
    public Author? Author { get; set; }

    [Range(0, int.MaxValue)]
    public int QuantityTotal { get; set; }

    [Range(0, int.MaxValue)]
    public int QuantityAvailable { get; set; }

    public string? Description { get; set; }
    public string? CoverImage { get; set; }
    public DateTime CreatedAt { get; set; } = DateTime.Now;

    // 1 Book - N BorrowRecord
    public ICollection<BorrowRecord> BorrowRecords { get; set; } = new List<BorrowRecord>();
    public ICollection<Review> Reviews { get; set; } = new List<Review>();
}
