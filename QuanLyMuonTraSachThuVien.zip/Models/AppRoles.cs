namespace BTL_SRS.Models;

public static class AppRoles
{
    public const string Admin = nameof(UserRole.Admin);
    public const string Librarian = nameof(UserRole.Librarian);
    public const string Reader = nameof(UserRole.Reader);
}
