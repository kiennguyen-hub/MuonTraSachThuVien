using System.ComponentModel.DataAnnotations;

namespace BTL_SRS.Models;

// Bang Categories (SRS 5.1, Table 10)
public class Category
{
    public int Id { get; set; }

    [Required, StringLength(100)]
    public string Name { get; set; } = "";

    // 1 Category - N Book
    public ICollection<Book> Books { get; set; } = new List<Book>();
}
