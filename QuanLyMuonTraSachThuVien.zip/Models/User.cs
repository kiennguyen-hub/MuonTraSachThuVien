using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;

namespace BTL_SRS.Models;

// Bang Users (SRS 5.1, Table 9)
public enum UserRole { Admin, Librarian, Reader }
public enum UserStatus { Active, Locked }

public class User : IdentityUser<int>
{
    [Required, StringLength(100)]
    public string FullName { get; set; } = "";

    public UserRole Role { get; set; } = UserRole.Reader;
    public UserStatus Status { get; set; } = UserStatus.Active;
    public DateTime CreatedAt { get; set; } = DateTime.Now;

    // 1 User - N BorrowRecord
    public ICollection<BorrowRecord> BorrowRecords { get; set; } = new List<BorrowRecord>();
    public ICollection<Review> Reviews { get; set; } = new List<Review>();
}
