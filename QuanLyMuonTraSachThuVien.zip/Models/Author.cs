using System.ComponentModel.DataAnnotations;

namespace BTL_SRS.Models;

// Tac gia (tach tu truong author dang text trong SRS de chuan hoa 1-n)
public class Author
{
    public int Id { get; set; }

    [Required, StringLength(100)]
    public string Name { get; set; } = "";

    public string? Bio { get; set; }

    // 1 Author - N Book
    public ICollection<Book> Books { get; set; } = new List<Book>();
}
