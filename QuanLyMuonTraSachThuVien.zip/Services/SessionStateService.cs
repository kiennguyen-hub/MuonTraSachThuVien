using System.Text.Json;
using BTL_SRS.Models;

namespace BTL_SRS.Services;

public class SessionUserState
{
    public int UserId { get; set; }
    public string FullName { get; set; } = "";
    public string UserName { get; set; } = "";
    public string Email { get; set; } = "";
    public string Role { get; set; } = "";
    public DateTimeOffset LoginAtUtc { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset LastActivityUtc { get; set; } = DateTimeOffset.UtcNow;
    public string? LastFunction { get; set; }
}

public class SessionStateService
{
    private const string SessionKey = "BTL_SRS.SessionUser";
    private readonly IHttpContextAccessor _httpContextAccessor;

    public SessionStateService(IHttpContextAccessor httpContextAccessor)
    {
        _httpContextAccessor = httpContextAccessor;
    }

    public SessionUserState? Get()
    {
        var value = _httpContextAccessor.HttpContext?.Session.GetString(SessionKey);
        if (string.IsNullOrWhiteSpace(value)) return null;

        try
        {
            return JsonSerializer.Deserialize<SessionUserState>(value);
        }
        catch (JsonException)
        {
            return null;
        }
    }

    public void Start(User user, IList<string> roles)
    {
        var state = new SessionUserState
        {
            UserId = user.Id,
            FullName = user.FullName,
            UserName = user.UserName ?? "",
            Email = user.Email ?? "",
            Role = roles.FirstOrDefault() ?? user.Role.ToString(),
            LoginAtUtc = DateTimeOffset.UtcNow,
            LastActivityUtc = DateTimeOffset.UtcNow
        };
        Save(state);
    }

    public void Touch(string? function)
    {
        var state = Get();
        if (state == null) return;

        state.LastActivityUtc = DateTimeOffset.UtcNow;
        if (!string.IsNullOrWhiteSpace(function)) state.LastFunction = function;
        Save(state);
    }

    public void Clear()
    {
        _httpContextAccessor.HttpContext?.Session.Remove(SessionKey);
    }

    private void Save(SessionUserState state)
    {
        _httpContextAccessor.HttpContext?.Session.SetString(SessionKey, JsonSerializer.Serialize(state));
    }
}
