namespace BTL_SRS.Services;

public class VisitorState
{
    public string VisitorId { get; set; } = Guid.NewGuid().ToString("N");
    public int VisitCount { get; set; }
    public DateTimeOffset FirstSeenUtc { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset LastAccessUtc { get; set; } = DateTimeOffset.UtcNow;
    public DateTimeOffset LastVisitUtc { get; set; } = DateTimeOffset.UtcNow;
    public string? LastFunction { get; set; }
    public Dictionary<string, int> FunctionUsage { get; set; } = new();

    public IReadOnlyList<KeyValuePair<string, int>> TopFunctions(int count = 5) =>
        FunctionUsage
            .OrderByDescending(item => item.Value)
            .ThenBy(item => item.Key)
            .Take(count)
            .ToList();
}
