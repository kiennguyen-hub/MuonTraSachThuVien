using System.Security.Cryptography;
using System.Text.Json;
using Microsoft.AspNetCore.DataProtection;

namespace BTL_SRS.Services;

public class VisitorStateService
{
    private const string CookieName = "BTL_SRS.VisitorState";
    private const string CountedSessionKey = "BTL_SRS.VisitorCounted";

    private readonly IHttpContextAccessor _httpContextAccessor;
    private readonly IDataProtector _protector;
    private readonly int _expireDays;
    private readonly JsonSerializerOptions _jsonOptions = new() { PropertyNameCaseInsensitive = true };

    public VisitorStateService(
        IHttpContextAccessor httpContextAccessor,
        IDataProtectionProvider dataProtectionProvider,
        IConfiguration configuration)
    {
        _httpContextAccessor = httpContextAccessor;
        _protector = dataProtectionProvider.CreateProtector("BTL_SRS.VisitorState.v1");
        _expireDays = configuration.GetValue<int?>("VisitorCookie:ExpireDays") ?? 30;
    }

    public VisitorState GetProfile()
    {
        var context = _httpContextAccessor.HttpContext;
        if (context == null) return new VisitorState();

        var value = context.Request.Cookies[CookieName];
        if (string.IsNullOrWhiteSpace(value)) return new VisitorState();

        try
        {
            var json = _protector.Unprotect(value);
            var state = JsonSerializer.Deserialize<VisitorState>(json, _jsonOptions);
            if (state == null) return new VisitorState();
            state.FunctionUsage ??= new Dictionary<string, int>();
            return state;
        }
        catch (CryptographicException)
        {
            return new VisitorState();
        }
        catch (JsonException)
        {
            return new VisitorState();
        }
    }

    public void Track(string? function)
    {
        var context = _httpContextAccessor.HttpContext;
        if (context == null) return;

        var state = GetProfile();
        var now = DateTimeOffset.UtcNow;

        if (context.Session.GetString(CountedSessionKey) != "1")
        {
            state.VisitCount++;
            state.LastVisitUtc = now;
            context.Session.SetString(CountedSessionKey, "1");
        }

        state.LastAccessUtc = now;
        if (!string.IsNullOrWhiteSpace(function))
        {
            state.LastFunction = function;
            state.FunctionUsage[function] = state.FunctionUsage.GetValueOrDefault(function) + 1;
        }

        Save(state);
    }

    public void Reset()
    {
        var context = _httpContextAccessor.HttpContext;
        if (context == null) return;

        context.Response.Cookies.Delete(CookieName, CookieOptions());
        context.Session.Remove(CountedSessionKey);
    }

    private void Save(VisitorState state)
    {
        var context = _httpContextAccessor.HttpContext;
        if (context == null) return;

        var json = JsonSerializer.Serialize(state);
        var value = _protector.Protect(json);
        context.Response.Cookies.Append(CookieName, value, CookieOptions());
    }

    private CookieOptions CookieOptions() => new()
    {
        Expires = DateTimeOffset.UtcNow.AddDays(_expireDays),
        Path = "/",
        HttpOnly = true,
        IsEssential = true,
        SameSite = SameSiteMode.Lax,
        Secure = _httpContextAccessor.HttpContext?.Request.IsHttps ?? false
    };
}
