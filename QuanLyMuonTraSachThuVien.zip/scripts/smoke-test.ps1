param(
    [string]$BaseUrl = "http://localhost:5001"
)

Add-Type -AssemblyName System.Net.Http

$ErrorActionPreference = "Stop"
$script:Passed = 0
$script:Failed = 0

function Assert-True {
    param([bool]$Condition, [string]$Name)
    if ($Condition) {
        $script:Passed++
        Write-Host "[PASS] $Name" -ForegroundColor Green
    }
    else {
        $script:Failed++
        Write-Host "[FAIL] $Name" -ForegroundColor Red
    }
}

function New-Client {
    $handler = [System.Net.Http.HttpClientHandler]::new()
    $handler.AllowAutoRedirect = $false
    $handler.CookieContainer = [System.Net.CookieContainer]::new()
    $client = [System.Net.Http.HttpClient]::new($handler)
    $client.BaseAddress = [Uri]$BaseUrl
    $client | Add-Member -NotePropertyName CookieContainer -NotePropertyValue $handler.CookieContainer
    return $client
}

function Get-Html {
    param($Client, [string]$Path)
    $response = $Client.GetAsync($Path).Result
    return @{
        Status = [int]$response.StatusCode
        Html = $response.Content.ReadAsStringAsync().Result
        Response = $response
    }
}

function Get-Token {
    param($Client, [string]$Path = "/Account/Login")
    $page = Get-Html $Client $Path
    $match = [regex]::Match($page.Html, 'name="__RequestVerificationToken"[^>]*value="([^"]+)"')
    if (-not $match.Success) {
        throw "Khong tim thay antiforgery token tai $Path"
    }
    return $match.Groups[1].Value
}

function Login {
    param($Client, [string]$User, [string]$Password = "123456")
    $token = Get-Token $Client
    $form = [System.Collections.Generic.Dictionary[string,string]]::new()
    $form["UserNameOrEmail"] = $User
    $form["Password"] = $Password
    $form["__RequestVerificationToken"] = $token
    $response = $Client.PostAsync(
        "/Account/Login",
        [System.Net.Http.FormUrlEncodedContent]::new($form)).Result
    return $response
}

function Get-Role {
    param([string]$Html)
    return [regex]::Match($Html, '<span class="badge bg-success me-1">([^<]+)</span>').Groups[1].Value
}

function Get-VisitCount {
    param([string]$Html)
    $match = [regex]::Match($Html, 'id="visitCount">(\d+)<')
    if (-not $match.Success) { return -1 }
    return [int]$match.Groups[1].Value
}

function Get-SetCookieHeaders {
    param($Response)
    $values = $null
    if ($Response.Headers.TryGetValues("Set-Cookie", [ref]$values)) {
        return @($values)
    }
    return @()
}

function Has-PersistentCookie {
    param([string[]]$Headers, [string]$Name)
    foreach ($header in $Headers) {
        if ($header.StartsWith("$Name=") -and $header -match "(?i)expires=") {
            return $true
        }
    }
    return $false
}

function Has-SessionCookie {
    param([string[]]$Headers, [string]$Name)
    foreach ($header in $Headers) {
        if ($header.StartsWith("$Name=") -and $header -notmatch "(?i)(expires|max-age)=") {
            return $true
        }
    }
    return $false
}

try {
    $probe = New-Client
    $loginPage = Get-Html $probe "/Account/Login"
    Assert-True ($loginPage.Status -eq 200) "Trang dang nhap tra ve HTTP 200"

    $anonymousHome = Get-Html $probe "/"
    Assert-True ($anonymousHome.Status -eq 302 -and $anonymousHome.Response.Headers.Location.PathAndQuery -like "/Account/Login*") `
        "Khach chua dang nhap bi chuyen ve trang dang nhap"

    $wrong = New-Client
    $wrongResponse = Login $wrong "admin" "wrong-password"
    $wrongHtml = [System.Net.WebUtility]::HtmlDecode($wrongResponse.Content.ReadAsStringAsync().Result)
    Assert-True ([int]$wrongResponse.StatusCode -eq 200 -and $wrongHtml.Contains('alert alert-danger')) `
        "Sai mat khau bi tu choi va hien thi thong bao"

    $admin = New-Client
    $adminLogin = Login $admin "admin"
    Assert-True ([int]$adminLogin.StatusCode -eq 302) "Admin dang nhap thanh cong"

    $adminHome = Get-Html $admin "/"
    Assert-True ($adminHome.Status -eq 200 -and $adminHome.Html.Contains('id="persistentCookiePanel"') -and $adminHome.Html.Contains('id="sessionPanel"')) `
        "Trang chu hien thi thong tin cookie va session"

    $adminProfile = Get-Html $admin "/Account/Profile"
    Assert-True ($adminProfile.Status -eq 200 -and (Get-Role $adminProfile.Html) -eq "Admin") `
        "Admin co role Admin trong Identity"

    $adminBooks = Get-Html $admin "/Books"
    Assert-True ($adminBooks.Status -eq 200 -and $adminBooks.Html.Contains('id="btnAddNew"') -and $adminBooks.Html.Contains('id="bookModal"')) `
        "Admin thay nut them/sua/xoa sach"

    $loginCookies = Get-SetCookieHeaders $adminLogin
    Assert-True (Has-PersistentCookie $loginCookies "BTL_SRS.VisitorState") `
        "VisitorState la persistent cookie co Expires"
    Assert-True (Has-SessionCookie $loginCookies "BTL_SRS.Auth") `
        "Auth la session cookie khong co Expires"

    $firstCount = Get-VisitCount $adminHome.Html
    Assert-True ($firstCount -ge 1) "Dem duoc so lan truy cap tu cookie ben"

    $newSession = New-Client
    $visitorCookie = $admin.CookieContainer.GetCookies([Uri]$BaseUrl)["BTL_SRS.VisitorState"]
    $newSession.CookieContainer.Add([Uri]$BaseUrl, $visitorCookie)
    $newSessionLogin = Login $newSession "admin"
    $newSessionHome = Get-Html $newSession "/"
    $secondCount = Get-VisitCount $newSessionHome.Html
    $newSessionOk = ([int]$newSessionLogin.StatusCode -eq 302 -and $secondCount -gt $firstCount)
    Assert-True $newSessionOk `
        "Cookie ben giu luot truy cap khi mo phien moi"

    $librarian = New-Client
    $librarianLogin = Login $librarian "thuthu"
    $librarianProfile = Get-Html $librarian "/Account/Profile"
    Assert-True ([int]$librarianLogin.StatusCode -eq 302 -and (Get-Role $librarianProfile.Html) -eq "Librarian") `
        "Thu thu dang nhap voi role Librarian"

    $reader = New-Client
    $readerLogin = Login $reader "docgia1"
    Assert-True ([int]$readerLogin.StatusCode -eq 302) "Doc gia dang nhap thanh cong"

    $readerProfile = Get-Html $reader "/Account/Profile"
    Assert-True ((Get-Role $readerProfile.Html) -eq "Reader") "Doc gia co role Reader"

    $readerBooks = Get-Html $reader "/Books"
    Assert-True ($readerBooks.Html.Contains('id="readOnlyBadge"') -and -not $readerBooks.Html.Contains('id="btnAddNew"')) `
        "Doc gia chi thay che do chi doc, khong co nut them sach"

    $readerToken = Get-Token $reader "/Books"
    $request = [System.Net.Http.HttpRequestMessage]::new([System.Net.Http.HttpMethod]::Post, "/Books/Create")
    $request.Content = [System.Net.Http.StringContent]::new(
        '{"title":"Blocked","authorId":1,"categoryId":1,"quantityTotal":1,"quantityAvailable":1,"description":"x"}',
        [System.Text.Encoding]::UTF8,
        "application/json")
    $request.Headers.Add("RequestVerificationToken", $readerToken)
    $blocked = $reader.SendAsync($request).Result
    Assert-True ([int]$blocked.StatusCode -eq 302 -and $blocked.Headers.Location.PathAndQuery -like "/Account/AccessDenied*") `
        "Doc gia bi chan khi goi API them sach"

    $logoutToken = Get-Token $admin "/"
    $logoutForm = [System.Collections.Generic.Dictionary[string,string]]::new()
    $logoutForm["__RequestVerificationToken"] = $logoutToken
    $logout = $admin.PostAsync("/Account/Logout", [System.Net.Http.FormUrlEncodedContent]::new($logoutForm)).Result
    $afterLogout = Get-Html $admin "/"
    Assert-True ([int]$logout.StatusCode -eq 302 -and $afterLogout.Status -eq 302) `
        "Dang xuat xoa quyen truy cap"
}
catch {
    $script:Failed++
    Write-Host "[ERROR] $($_.Exception.Message)" -ForegroundColor Red
}

Write-Host ""
Write-Host "Ket qua: $script:Passed PASS, $script:Failed FAIL" -ForegroundColor Cyan
if ($script:Failed -gt 0) { exit 1 }
