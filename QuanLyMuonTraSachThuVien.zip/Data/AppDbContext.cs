using BTL_SRS.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace BTL_SRS.Data;

public class AppDbContext : IdentityDbContext<User, IdentityRole<int>, int>
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<Category> Categories => Set<Category>();
    public DbSet<Author> Authors => Set<Author>();
    public DbSet<Book> Books => Set<Book>();
    public DbSet<BorrowRecord> BorrowRecords => Set<BorrowRecord>();
    public DbSet<Review> Reviews => Set<Review>();

    protected override void OnModelCreating(ModelBuilder b)
    {
        base.OnModelCreating(b);

        // Giu nguyen ten bang Users de khong mat du lieu khi nang cap len Identity.
        b.Entity<User>().ToTable("Users");
        b.Entity<IdentityRole<int>>().ToTable("Roles");
        b.Entity<IdentityUserRole<int>>().ToTable("UserRoles");
        b.Entity<IdentityUserClaim<int>>().ToTable("UserClaims");
        b.Entity<IdentityUserLogin<int>>().ToTable("UserLogins");
        b.Entity<IdentityRoleClaim<int>>().ToTable("RoleClaims");
        b.Entity<IdentityUserToken<int>>().ToTable("UserTokens");

        b.Entity<User>().Property(u => u.FullName).HasMaxLength(100).IsRequired();
        b.Entity<User>().Property(u => u.Role).HasConversion<int>();
        b.Entity<User>().Property(u => u.Status).HasConversion<int>();

        // tranh xoa cung User/Book khi con phieu muon (SRS 5.3)
        b.Entity<BorrowRecord>().HasOne(r => r.User).WithMany(u => u.BorrowRecords)
            .HasForeignKey(r => r.UserId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<BorrowRecord>().HasOne(r => r.Book).WithMany(x => x.BorrowRecords)
            .HasForeignKey(r => r.BookId).OnDelete(DeleteBehavior.Restrict);
        b.Entity<BorrowRecord>().HasOne(r => r.Approver).WithMany()
            .HasForeignKey(r => r.ApprovedBy).OnDelete(DeleteBehavior.SetNull);

        b.Entity<Review>().HasOne(r => r.Book).WithMany(x => x.Reviews)
            .HasForeignKey(r => r.BookId).OnDelete(DeleteBehavior.Cascade);
        b.Entity<Review>().HasOne(r => r.User).WithMany(u => u.Reviews)
            .HasForeignKey(r => r.UserId).OnDelete(DeleteBehavior.Cascade);

        b.Entity<Book>().Property(x => x.QuantityTotal).HasDefaultValue(0);
        b.Entity<Book>().Property(x => x.QuantityAvailable).HasDefaultValue(0);
    }
}
