using BTL_SRS.Models;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;

namespace BTL_SRS.Data;

// Du lieu mau cho buoi 6 - 10 dau sach de test CRUD, tim kiem, sap xep, phan trang
public static class SeedData
{
    private static readonly string[] CategoryNames =
        { "Cong nghe thong tin", "Van hoc", "Kinh te", "Ky nang song" };

    private static readonly string[] AuthorNames =
        { "Nguyen Van A", "Tran Thi B", "Le Van C", "Pham Minh D" };

    // Title, Category, Author, Total, Available, Description
    private static readonly (string Title, string Category, string Author, int Total, int Available, string Description)[] SampleBooks =
    {
        ("Lap trinh C# co ban", "Cong nghe thong tin", "Nguyen Van A", 10, 8, "Sach nhap mon C#"),
        ("ASP.NET Core MVC", "Cong nghe thong tin", "Nguyen Van A", 5, 5, "Lap trinh web nang cao"),
        ("Clean Code", "Cong nghe thong tin", "Pham Minh D", 8, 7, "Ky nang viet ma sach"),
        ("Co so du lieu", "Cong nghe thong tin", "Pham Minh D", 6, 2, "Giao trinh co so du lieu"),
        ("Truyen Kieu", "Van hoc", "Tran Thi B", 7, 6, "Tac pham van hoc kinh dien"),
        ("Dac nhan tam", "Van hoc", "Le Van C", 12, 10, "Ky nang song"),
        ("Nha gia kim", "Van hoc", "Le Van C", 9, 9, "Tieu thuyet kinh dien"),
        ("Kinh te vi mo", "Kinh te", "Le Van C", 6, 4, "Giao trinh dai hoc"),
        ("Khoi nghiep tinh gon", "Kinh te", "Tran Thi B", 4, 3, "Sach khoi nghiep"),
        ("Ky nang giao tiep", "Ky nang song", "Tran Thi B", 3, 0, "Sach dang het de test trang thai"),
    };

    public static async Task InitAsync(
        AppDbContext db,
        UserManager<User> userManager,
        RoleManager<IdentityRole<int>> roleManager)
    {
        foreach (var name in CategoryNames)
            if (!db.Categories.Any(c => c.Name == name))
                db.Categories.Add(new Category { Name = name });

        foreach (var name in AuthorNames)
            if (!db.Authors.Any(a => a.Name == name))
                db.Authors.Add(new Author { Name = name });

        await db.SaveChangesAsync();

        var categoryIds = db.Categories.AsEnumerable().GroupBy(c => c.Name).ToDictionary(g => g.Key, g => g.First().Id);
        var authorIds = db.Authors.AsEnumerable().GroupBy(a => a.Name).ToDictionary(g => g.Key, g => g.First().Id);

        foreach (var item in SampleBooks)
        {
            if (db.Books.Any(b => b.Title == item.Title)) continue;

            db.Books.Add(new Book
            {
                Title = item.Title,
                CategoryId = categoryIds[item.Category],
                AuthorId = authorIds[item.Author],
                QuantityTotal = item.Total,
                QuantityAvailable = item.Available,
                Description = item.Description
            });
        }

        await db.SaveChangesAsync();

        foreach (var role in new[] { AppRoles.Admin, AppRoles.Librarian, AppRoles.Reader })
        {
            if (!await roleManager.RoleExistsAsync(role))
                await roleManager.CreateAsync(new IdentityRole<int>(role));
        }

        var sampleUsers = new[]
        {
            (FullName: "Admin", UserName: "admin", Email: "admin@lib.vn", Role: AppRoles.Admin),
            (FullName: "Thu thu", UserName: "thuthu", Email: "thuthu@lib.vn", Role: AppRoles.Librarian),
            (FullName: "Doc gia 1", UserName: "docgia1", Email: "docgia1@lib.vn", Role: AppRoles.Reader)
        };

        foreach (var sample in sampleUsers)
        {
            var user = await db.Users.FirstOrDefaultAsync(u =>
                u.UserName == sample.UserName || u.Email == sample.Email);

            if (user == null)
            {
                user = new User
                {
                    FullName = sample.FullName,
                    UserName = sample.UserName,
                    Email = sample.Email,
                    EmailConfirmed = true,
                    Role = Enum.Parse<UserRole>(sample.Role),
                    Status = UserStatus.Active
                };

                var createResult = await userManager.CreateAsync(user, "123456");
                if (!createResult.Succeeded)
                    throw new InvalidOperationException(
                        $"Khong tao duoc user {sample.UserName}: {string.Join("; ", createResult.Errors.Select(e => e.Description))}");
            }
            else
            {
                user.FullName = sample.FullName;
                user.Email = sample.Email;
                user.EmailConfirmed = true;
                user.Role = Enum.Parse<UserRole>(sample.Role);
                user.Status = UserStatus.Active;
                user.SecurityStamp ??= Guid.NewGuid().ToString();
                user.ConcurrencyStamp ??= Guid.NewGuid().ToString();

                // Du lieu cu luu mat khau dang plain text. Chuyen sang hash cua Identity.
                if (string.IsNullOrWhiteSpace(user.PasswordHash) ||
                    userManager.PasswordHasher.VerifyHashedPassword(user, user.PasswordHash, "123456")
                        == PasswordVerificationResult.Failed)
                {
                    user.PasswordHash = userManager.PasswordHasher.HashPassword(user, "123456");
                }

                await userManager.UpdateAsync(user);
            }

            var currentRoles = await userManager.GetRolesAsync(user);
            foreach (var role in currentRoles.Where(r => r != sample.Role))
                await userManager.RemoveFromRoleAsync(user, role);

            if (!await userManager.IsInRoleAsync(user, sample.Role))
                await userManager.AddToRoleAsync(user, sample.Role);
        }
    }
}
