window.PhucBooks = {
    getDetails(id, onSuccess, onError) {
        fetch('/Books/GetDetails/' + id, { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
            .then(response => response.json())
            .then(result => result.success ? onSuccess(result.data) : onError(result.message))
            .catch(error => onError(error.message));
    },

    edit(id, book, token, onSuccess, onError) {
        $.ajax({
            url: '/Books/Edit/' + id,
            type: 'PUT',
            contentType: 'application/json',
            headers: { RequestVerificationToken: token },
            data: JSON.stringify(book),
            success: result => result.success ? onSuccess(result) : onError(result.message),
            error: xhr => onError(xhr.responseJSON?.message || 'Không thể sửa sách.')
        });
    },

    remove(id, token, onSuccess, onError) {
        $.ajax({
            url: '/Books/Delete/' + id,
            type: 'DELETE',
            headers: { RequestVerificationToken: token },
            success: result => result.success ? onSuccess(result) : onError(result.message),
            error: xhr => onError(xhr.responseJSON?.message || 'Không thể xóa sách.')
        });
    }
};
