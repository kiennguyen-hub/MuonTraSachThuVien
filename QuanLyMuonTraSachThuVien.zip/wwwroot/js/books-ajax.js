const BooksAjax = {
    bookModalBS: null,
    detailModalBS: null,
    deleteModalBS: null,
    deleteBookId: null,

    init() {
        const bookModal = document.getElementById('bookModal');
        const deleteModal = document.getElementById('deleteModal');
        this.bookModalBS = bookModal ? new bootstrap.Modal(bookModal) : null;
        this.detailModalBS = new bootstrap.Modal(document.getElementById('detailModal'));
        this.deleteModalBS = deleteModal ? new bootstrap.Modal(deleteModal) : null;
        this.bindEvents();
        this.loadBooksWithXhr(1);
    },

    bindEvents() {
        document.getElementById('btnFilter').addEventListener('click', () => this.searchBooks());
        document.getElementById('searchInput').addEventListener('keypress', event => {
            if (event.key === 'Enter') this.searchBooks();
        });
        document.getElementById('sortFilter').addEventListener('change', () => {
            PhongBooks.applySort();
            this.loadBooksWithXhr(1);
        });
        document.getElementById('categoryFilter').addEventListener('change', () => this.loadBooksWithXhr(1));
        const addButton = document.getElementById('btnAddNew');
        if (addButton) addButton.addEventListener('click', () => this.resetForm());
        const bookForm = document.getElementById('bookForm');
        const confirmDeleteButton = document.getElementById('confirmDeleteBtn');
        if (bookForm) bookForm.addEventListener('submit', event => this.saveBook(event));
        if (confirmDeleteButton) confirmDeleteButton.addEventListener('click', () => this.confirmDelete());
    },

    loadBooksWithXhr(page) {
        this.showLoading(true);
        PhongBooks.currentCategory = document.getElementById('categoryFilter').value;
        PhongBooks.loadListWithXhr(page, result => {
            KienBooks.renderPagination(result.pagination, selectedPage => this.loadBooksWithXhr(selectedPage));
            this.showLoading(false);
        }, message => {
            this.showAlert('Lỗi', message, 'danger');
            this.showLoading(false);
        });
    },

    searchBooks() {
        this.showLoading(true);
        PhongBooks.searchWithFetch(result => {
            KienBooks.renderPagination(result.pagination, selectedPage => this.loadBooksWithXhr(selectedPage));
            this.showLoading(false);
        }, message => {
            this.showAlert('Lỗi', message, 'danger');
            this.showLoading(false);
        });
    },

    viewDetails(id) {
        PhucBooks.getDetails(id, book => {
            document.getElementById('detailTitle').textContent = book.title;
            document.getElementById('detailAuthor').textContent = book.authorName;
            document.getElementById('detailCategory').textContent = book.categoryName;
            document.getElementById('detailQuantity').textContent = `${book.quantityAvailable}/${book.quantityTotal}`;
            document.getElementById('detailDescription').textContent = book.description || 'Không có mô tả';
            this.detailModalBS.show();
        }, message => this.showAlert('Lỗi', message, 'danger'));
    },

    resetForm() {
        document.getElementById('bookForm').reset();
        document.getElementById('bookId').value = '';
        document.getElementById('bookModalTitle').textContent = 'Thêm Sách Mới';
        document.getElementById('submitBtnText').textContent = 'Lưu';
    },

    editBook(id) {
        PhucBooks.getDetails(id, book => {
            document.getElementById('bookId').value = book.id;
            document.getElementById('bookTitle').value = book.title;
            document.getElementById('bookAuthor').value = book.authorId;
            document.getElementById('bookCategory').value = book.categoryId;
            document.getElementById('bookQuantityTotal').value = book.quantityTotal;
            document.getElementById('bookQuantityAvailable').value = book.quantityAvailable;
            document.getElementById('bookDescription').value = book.description || '';
            document.getElementById('bookModalTitle').textContent = 'Sửa Sách';
            document.getElementById('submitBtnText').textContent = 'Cập Nhật';
            this.bookModalBS.show();
        }, message => this.showAlert('Lỗi', message, 'danger'));
    },

    saveBook(event) {
        event.preventDefault();
        const book = this.readBookForm();
        const bookId = document.getElementById('bookId').value;
        const done = result => {
            this.showAlert('Thành công', result.message, 'success');
            this.bookModalBS.hide();
            this.loadBooksWithXhr(PhongBooks.currentPage);
        };
        const fail = message => this.showAlert('Lỗi', message, 'danger');
        if (bookId) PhucBooks.edit(bookId, book, this.getCsrfToken(), done, fail);
        else KienBooks.add(book, this.getCsrfToken(), done, fail);
    },

    deleteBook(id) {
        this.deleteBookId = id;
        this.deleteModalBS.show();
    },

    confirmDelete() {
        PhucBooks.remove(this.deleteBookId, this.getCsrfToken(), result => {
            this.showAlert('Thành công', result.message, 'success');
            this.deleteModalBS.hide();
            this.loadBooksWithXhr(PhongBooks.currentPage);
        }, message => this.showAlert('Lỗi', message, 'danger'));
    },

    readBookForm() {
        return {
            title: document.getElementById('bookTitle').value,
            authorId: Number(document.getElementById('bookAuthor').value),
            categoryId: Number(document.getElementById('bookCategory').value),
            quantityTotal: Number(document.getElementById('bookQuantityTotal').value),
            quantityAvailable: Number(document.getElementById('bookQuantityAvailable').value),
            description: document.getElementById('bookDescription').value
        };
    },

    getCsrfToken() {
        return document.querySelector('input[name="__RequestVerificationToken"]').value;
    },

    showLoading(show) {
        document.getElementById('loadingIndicator').classList.toggle('d-none', !show);
    },

    showAlert(title, message, type) {
        const alert = document.createElement('div');
        alert.className = `alert alert-${type} alert-dismissible fade show`;
        alert.innerHTML = `<strong>${title}</strong> ${message}<button type="button" class="btn-close" data-bs-dismiss="alert"></button>`;
        document.querySelector('.container-fluid').prepend(alert);
        setTimeout(() => alert.remove(), 5000);
    }
};

document.addEventListener('DOMContentLoaded', () => BooksAjax.init());
