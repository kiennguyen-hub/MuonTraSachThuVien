window.KienBooks = {
    add(book, token, onSuccess, onError) {
        $.ajax({
            url: '/Books/Create',
            type: 'POST',
            contentType: 'application/json',
            headers: { RequestVerificationToken: token },
            data: JSON.stringify(book),
            success: result => result.success ? onSuccess(result) : onError(result.message),
            error: xhr => onError(xhr.responseJSON?.message || 'Không thể thêm sách.')
        });
    },

    renderPagination(pagination, onPage) {
        const element = document.getElementById('pagination');
        if (!element || pagination.totalPages <= 1) {
            if (element) element.innerHTML = '';
            return;
        }

        let html = `<li class="page-item ${pagination.page === 1 ? 'disabled' : ''}">
            <button class="page-link" data-page="${pagination.page - 1}">Trước</button></li>`;
        for (let page = 1; page <= pagination.totalPages; page++) {
            html += `<li class="page-item ${page === pagination.page ? 'active' : ''}">
                <button class="page-link" data-page="${page}">${page}</button></li>`;
        }
        html += `<li class="page-item ${pagination.page === pagination.totalPages ? 'disabled' : ''}">
            <button class="page-link" data-page="${pagination.page + 1}">Sau</button></li>`;
        element.innerHTML = html;
        element.querySelectorAll('button[data-page]').forEach(button => {
            button.addEventListener('click', () => {
                const page = Number(button.dataset.page);
                if (page >= 1 && page <= pagination.totalPages) onPage(page);
            });
        });
    }
};
