window.PhongBooks = {
    currentSearch: '',
    currentCategory: '',
    currentSort: 'title',
    currentPage: 1,
    pageSize: 5,

    buildUrl(page) {
        const params = new URLSearchParams({
            q: this.currentSearch,
            catId: this.currentCategory,
            sort: this.currentSort,
            page: page || this.currentPage
        });
        return '/Books/GetList?' + params.toString();
    },

    loadListWithXhr(page, onSuccess, onError) {
        this.currentPage = page || 1;
        const xhr = new XMLHttpRequest();
        xhr.open('GET', this.buildUrl(this.currentPage), true);
        xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
        xhr.onload = () => {
            if (xhr.status >= 200 && xhr.status < 300) {
                const result = JSON.parse(xhr.responseText);
                if (result.success) {
                    this.renderTable(result.data, result.pagination);
                    onSuccess(result);
                } else {
                    onError(result.message);
                }
            } else {
                onError('Không thể tải danh sách sách.');
            }
        };
        xhr.onerror = () => onError('Lỗi kết nối khi tải danh sách sách.');
        xhr.send();
    },

    searchWithFetch(onSuccess, onError) {
        this.currentSearch = document.getElementById('searchInput').value.trim();
        this.currentCategory = document.getElementById('categoryFilter').value;
        this.currentPage = 1;
        fetch(this.buildUrl(1), { headers: { 'X-Requested-With': 'XMLHttpRequest' } })
            .then(response => response.json())
            .then(result => {
                if (!result.success) throw new Error(result.message);
                this.renderTable(result.data, result.pagination);
                onSuccess(result);
            })
            .catch(error => onError(error.message));
    },

    applySort() {
        this.currentSort = document.getElementById('sortFilter').value;
        this.currentPage = 1;
    },

    renderTable(books, pagination) {
        const tbody = document.getElementById('booksTableBody');
        if (!tbody) return;
        if (!books || books.length === 0) {
            tbody.innerHTML = '<tr><td colspan="6" class="text-center text-muted py-5">Không có sách nào</td></tr>';
            return;
        }

        const firstRow = (pagination.page - 1) * pagination.size + 1;
        tbody.innerHTML = books.map((book, index) => {
            const badge = book.quantityAvailable > 0 ? 'bg-success' : 'bg-danger';
            return `<tr>
                <td><span class="badge bg-secondary">${firstRow + index}</span></td>
                <td><strong>${this.escapeHtml(book.title)}</strong><br><small class="text-muted">${this.escapeHtml(book.description || '')}</small></td>
                <td>${this.escapeHtml(book.authorName)}</td>
                <td>${this.escapeHtml(book.categoryName)}</td>
                <td><span class="badge ${badge}">${book.quantityAvailable}/${book.quantityTotal}</span></td>
                <td>
                    <button class="btn btn-sm btn-outline-primary" onclick="BooksAjax.viewDetails(${book.id})">Chi tiết</button>
                    ${window.canManageBooks ? `
                    <button class="btn btn-sm btn-info" onclick="BooksAjax.editBook(${book.id})">Sửa</button>
                    <button class="btn btn-sm btn-danger" onclick="BooksAjax.deleteBook(${book.id})">Xóa</button>` : ''}
                </td>
            </tr>`;
        }).join('');
    },

    escapeHtml(value) {
        const element = document.createElement('div');
        element.textContent = value == null ? '' : String(value);
        return element.innerHTML;
    }
};
