using BTL_SRS.Data;
using BTL_SRS.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BTL_SRS.Controllers;

// Module ca nhan: CRUD sach (FR-06 den FR-09) + Query Pipeline (Search/Sort/Paging - FR-07, FR-10)
[Authorize]
public class BooksController : Controller
{
    private readonly AppDbContext _db;
    public BooksController(AppDbContext db) => _db = db;

    // GET: /Books - Render UI trang Index (Load trang trước)
    public async Task<IActionResult> Index()
    {
        // Chỉ render skeleton UI, dữ liệu sẽ được AJAX tải
        var categories = await _db.Categories.AsNoTracking().OrderBy(c => c.Name).ToListAsync();
        var authors = await _db.Authors.AsNoTracking().OrderBy(a => a.Name).ToListAsync();
        
        ViewBag.Categories = categories;
        ViewBag.Authors = authors;
        ViewBag.DefaultSort = "title";
        ViewBag.DefaultPage = 1;
        ViewBag.CanManage = User.IsInRole(AppRoles.Admin) || User.IsInRole(AppRoles.Librarian);
        
        return View();
    }

    // API: GET /Books/GetList - Trả về dữ liệu JSON cho AJAX
    [HttpGet]
    [Route("Books/GetList")]
    public async Task<IActionResult> GetList(string? q, int? catId, string sort = "title", int page = 1)
    {
        try
        {
            if (page < 1) page = 1;
            const int size = 5;

            var query = _db.Books.Include(b => b.Category).Include(b => b.Author).AsNoTracking().AsQueryable();
            
            if (!string.IsNullOrWhiteSpace(q))
                query = query.Where(b => b.Title.Contains(q) || (b.Author != null && b.Author.Name.Contains(q)));
            
            if (catId.HasValue)
                query = query.Where(b => b.CategoryId == catId.Value);
            
            query = sort == "new" ? query.OrderByDescending(b => b.Id) : query.OrderBy(b => b.Title);

            var total = await query.CountAsync();
            var totalPages = Math.Max(1, (int)Math.Ceiling(total / (double)size));
            if (page > totalPages) page = totalPages;

            var books = await query.Skip((page - 1) * size).Take(size).ToListAsync();

            return Json(new
            {
                success = true,
                data = books.Select(b => new
                {
                    b.Id,
                    b.Title,
                    authorName = b.Author?.Name ?? "N/A",
                    categoryName = b.Category?.Name ?? "N/A",
                    b.QuantityTotal,
                    b.QuantityAvailable,
                    b.Description
                }),
                pagination = new
                {
                    page,
                    totalPages,
                    total,
                    size
                }
            });
        }
        catch (Exception ex)
        {
            return Json(new { success = false, message = ex.Message });
        }
    }

    // API: POST /Books/Create - Tạo sách mới (AJAX)
    [HttpPost]
    [Route("Books/Create")]
    [Authorize(Policy = "ManageBooks")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> CreateApi([FromBody] Book book)
    {
        try
        {
            if (!ModelState.IsValid)
                return Json(new { success = false, message = "Dữ liệu không hợp lệ", errors = ModelState.Values.SelectMany(v => v.Errors.Select(e => e.ErrorMessage)) });

            _db.Books.Add(book);
            await _db.SaveChangesAsync();

            return Json(new
            {
                success = true,
                message = "Thêm sách thành công",
                data = new
                {
                    book.Id,
                    book.Title,
                    authorName = _db.Authors.Find(book.AuthorId)?.Name ?? "N/A",
                    categoryName = _db.Categories.Find(book.CategoryId)?.Name ?? "N/A",
                    book.QuantityTotal,
                    book.QuantityAvailable,
                    book.Description
                }
            });
        }
        catch (Exception ex)
        {
            return Json(new { success = false, message = $"Lỗi: {ex.Message}" });
        }
    }

    // API: PUT /Books/Edit/5 - Cập nhật sách (AJAX)
    [HttpPut]
    [Route("Books/Edit/{id}")]
    [Authorize(Policy = "ManageBooks")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> EditApi(int id, [FromBody] Book bookData)
    {
        try
        {
            var book = await _db.Books.FindAsync(id);
            if (book == null)
                return Json(new { success = false, message = "Sách không tìm thấy" });

            book.Title = bookData.Title;
            book.CategoryId = bookData.CategoryId;
            book.AuthorId = bookData.AuthorId;
            book.QuantityTotal = bookData.QuantityTotal;
            book.QuantityAvailable = bookData.QuantityAvailable;
            book.Description = bookData.Description;

            if (!ModelState.IsValid)
                return Json(new { success = false, message = "Dữ liệu không hợp lệ", errors = ModelState.Values.SelectMany(v => v.Errors.Select(e => e.ErrorMessage)) });

            _db.Update(book);
            await _db.SaveChangesAsync();

            return Json(new
            {
                success = true,
                message = "Cập nhật sách thành công",
                data = new
                {
                    book.Id,
                    book.Title,
                    authorName = _db.Authors.Find(book.AuthorId)?.Name ?? "N/A",
                    categoryName = _db.Categories.Find(book.CategoryId)?.Name ?? "N/A",
                    book.QuantityTotal,
                    book.QuantityAvailable,
                    book.Description
                }
            });
        }
        catch (Exception ex)
        {
            return Json(new { success = false, message = $"Lỗi: {ex.Message}" });
        }
    }

    // API: DELETE /Books/Delete/5 - Xoá sách (AJAX)
    [HttpDelete]
    [Route("Books/Delete/{id}")]
    [Authorize(Policy = "ManageBooks")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteApi(int id)
    {
        try
        {
            var book = await _db.Books.FindAsync(id);
            if (book == null)
                return Json(new { success = false, message = "Sách không tìm thấy" });

            // SRS 5.3: khong xoa sach dang duoc muon
            bool dangMuon = await _db.BorrowRecords.AnyAsync(r =>
                r.BookId == id && (r.Status == BorrowStatus.Borrowed || r.Status == BorrowStatus.Pending));
            
            if (dangMuon)
                return Json(new { success = false, message = "Không xóa được: sách đang có phiếu mượn" });

            _db.Books.Remove(book);
            await _db.SaveChangesAsync();

            return Json(new { success = true, message = "Xóa sách thành công" });
        }
        catch (Exception ex)
        {
            return Json(new { success = false, message = $"Lỗi: {ex.Message}" });
        }
    }

    // API: GET /Books/GetDetails/5 - Lấy chi tiết sách (AJAX)
    [HttpGet]
    [Route("Books/GetDetails/{id}")]
    public async Task<IActionResult> GetDetails(int? id)
    {
        try
        {
            if (id == null)
                return Json(new { success = false, message = "ID không hợp lệ" });

            var book = await _db.Books.Include(b => b.Category).Include(b => b.Author)
                .AsNoTracking().FirstOrDefaultAsync(b => b.Id == id);

            if (book == null)
                return Json(new { success = false, message = "Sách không tìm thấy" });

            return Json(new
            {
                success = true,
                data = new
                {
                    book.Id,
                    book.Title,
                    book.AuthorId,
                    book.CategoryId,
                    book.QuantityTotal,
                    book.QuantityAvailable,
                    book.Description,
                    authorName = book.Author?.Name ?? "N/A",
                    categoryName = book.Category?.Name ?? "N/A"
                }
            });
        }
        catch (Exception ex)
        {
            return Json(new { success = false, message = $"Lỗi: {ex.Message}" });
        }
    }

}
