using BTL_SRS.Data;
using BTL_SRS.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace BTL_SRS.Controllers;

[Authorize]
public class HomeController : Controller
{
    private readonly AppDbContext _db;
    private readonly VisitorStateService _visitorState;
    private readonly SessionStateService _sessionState;

    public HomeController(
        AppDbContext db,
        VisitorStateService visitorState,
        SessionStateService sessionState)
    {
        _db = db;
        _visitorState = visitorState;
        _sessionState = sessionState;
    }

    public async Task<IActionResult> Index()
    {
        ViewBag.TotalBooks = await _db.Books.CountAsync();
        ViewBag.TotalUsers = await _db.Users.CountAsync();
        ViewBag.Borrowed = await _db.BorrowRecords.CountAsync(r => r.Status == Models.BorrowStatus.Borrowed);
        ViewBag.Visitor = _visitorState.GetProfile();
        ViewBag.Session = _sessionState.Get();
        return View();
    }
}
